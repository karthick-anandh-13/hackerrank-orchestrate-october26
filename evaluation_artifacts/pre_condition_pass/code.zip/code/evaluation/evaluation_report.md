# Evaluation Report

## Public sample

Compared the deterministic pipeline with the 32 participant-visible examples in `dataset/sample_output.csv`. These scores measure agreement with the public sample, not hidden-set accuracy.

| Metric | Result |
| --- | ---: |
| Deletion-status accuracy | 29 / 32 (90.63%) |
| Position-aligned exact step recall | 114 / 193 expected steps (59.07%) |
| Position-aligned exact step precision | 114 / 159 predicted steps (71.70%) |
| Field accuracy | 952 / 1,358 field positions (70.10%) |
| Exact ordered status and sequence accuracy | 8 / 32 (25.00%) |

### Step mismatch diagnosis and canonical output taxonomy

The current 32-case comparison has 8 exact rows and 24 mismatches: 23 cases have missing expected steps (`case_01`, `case_02`, `case_03`, `case_04`, `case_06`, `case_07`, `case_08`, `case_09`, `case_10`, `case_18`, `case_20`, `case_21`, `case_22`, `case_23`, `case_24`, `case_25`, `case_26`, `case_27`, `case_28`, `case_29`, `case_30`, `case_31`, `case_32`); one has an extra step (`case_17`); and zero are reordered-but-same-content. There are 35 missing expected step entries in total. The contact-index policy correction resolved the prior wrong-content mismatch in `case_10`; its separate expected account verification remains unsupported by linked evidence. The main remaining mismatch is resource/proof coverage, not step ordering.

The three status mismatches (`case_01`, `case_02`, `case_04`) are expected `COMPLETE` but currently `INCOMPLETE`. The sample cites `evidence_54` for absent account records that do not occur in `dataset/evidence/databases/customer_accounts_failover_replica_20260902.sql`. `case_04` also cites `analytics_901` in `evidence_56`, but that JSON record has no subject identifier; the record cannot be linked to the case from participant-visible evidence. The pipeline retains fail-closed `INCOMPLETE` rather than inventing a link or treating missing evidence as proof. `case_17` has one additional planned absence check for an older, identity-linked account resource in the presence of an active backup path; the public answer omits it, and this remains an explicit evidence-scope judgment difference.

### Follow-up: no-discovery missing steps

The current detailed diff identifies 35 missing expected step entries across 23 sample cases. The earlier 34-step count excluded the separate unsupported `account_010` verification that became visible after correcting the contact-index policy classification. The resource gaps cluster into three systems:

The preceding diagnosis found 12 A-class steps (four each in `case_26`–`case_28`) suppressed by a case-level backup retention check. Those steps now emit; each case includes its security, support, flow, and blocked-backup verification, and all three statuses now match the sample. The 35 current missing entries below refer to expected resources not discovered with usable, temporally valid subject linkage.

| Resource/system type | Missing steps | Cases | Evidence source candidates / limitation |
| --- | ---: | --- | --- |
| Account profiles (`account_service`) | 21 | `case_01`, `case_02`, `case_04`, `case_06`, `case_07`, `case_08`, `case_09`, `case_10`, `case_18`, `case_20`, `case_21`, `case_22`, `case_23`, `case_25`, `case_26`, `case_27`, `case_28`, `case_29`, `case_30`, `case_31`, `case_32` | 15 have no item-level artifact for the expected resource. Other candidates are either not linked to the subject or captured after `audit_at`; activity rows alone remain claims. Some expected citations do not contain their named resource ID. |
| Analytics profiles (`analytics_platform`) | 7 | `case_03`, `case_04`, `case_21`, `case_25`, `case_26`, `case_27`, `case_28` | Candidate records have no usable subject identifier at the cutoff; later snapshots cannot establish state at an earlier `audit_at`. |
| Retained audit records (`security_service`) | 7 | `case_09`, `case_18`, `case_20`, `case_23`, `case_24`, `case_29`, `case_30` | 4 JSON and 1 log candidate were captured after `audit_at`; 2 have no participant evidence artifact. Later evidence cannot establish earlier state. |

Across the current 35 missing entries, 17 have no item-level evidence for the resource; 14 of those have resource-specific activity rows, but those rows do not identify the subject and cannot prove the state. The remaining candidates are unlinked and/or post-cutoff. There are no usable PDF or screenshot candidates. The gap is concentrated by system type—account profile discovery is the largest target—but spans evidence availability, lineage, and temporal-validity issues, so it is not a single parser fix. A row-level provenance audit is saved under `evaluation_artifacts/public_missing_step_resource_audit.csv` and `.json`.

The contract and sample encode three emitted phases: `FINDING`, `REMEDIATION`, `VERIFICATION`. Within phases, the conditional operation order is: remaining record, exposed PII, active flow, restore risk; disable flow, block restore, delete, redact, anonymize; verify absent, present, redacted, anonymized, flow disabled, restore blocked. Ties sort by system then resource ID. There is no “no action required” operation. A relevant resource with no remediation still appears as an evidence-backed verification step. The ordered taxonomy is now explicit and tested against reversed resource discovery order; no case IDs are special-cased.

No public cases were held out: all 32 were inspected for diagnosis. The full sample is therefore a diagnostic comparison, not a blind holdout.

### Representative case: case_18

The request is classified as an authorized Data Erasure request. Entity resolution maps the supplied address to `user_50` using the current identity snapshot in `dataset/user_identities.csv`; the identity audit history contains a phone change but no email change for this subject. At `audit_at=2026-09-26T11:00:00Z`, the evidence index links four resources through the readback log `evidence_94` (`dataset/evidence/logs/resource_lookup_trace_20260926_103856.log`): search record `search_4013` is a hit (lines 52–53); analytics record `analytics_037` still contains an email (lines 22–23); support record `support_5569` contains a requester email (lines 10–11); connector `data_flow_4890` is enabled (lines 24–25).

Policy-as-Code maps those states to deletion of the search record, anonymization of analytics, redaction of the support message, and disabling the connector. The generated `INCOMPLETE` plan places the flow control first, then the record actions, followed by one post-action verification per affected record or process. Those verification steps have empty `evidence_id` values because they describe future checks, not executed work. The plan does not claim those actions have happened.

This chain is limited to the four directly linked resources. The public expected row also names an account resource and retained audit record that are not present under those resource IDs in the cited readback file; the system activity entry for the account is a workflow claim, not proof of its current state. The pipeline leaves those resources unasserted rather than copying unsupported labels. This illustrates why sample sequence agreement is not equivalent to evidence quality.

The 518-case evaluation set has no participant-visible labels. Hidden deletion-status, step, and sequence accuracy therefore remain unknown. `python3 -m code.validate_output` independently checks output coverage, serialization, allowed operation/state pairs, temporal evidence references, and phase structure; it does not claim hidden-label correctness. See `evidence_coverage_report.md` for case-level evidence-chain measurements and their open-world inventory limitation.

## Participant-created regression cases

Run with `python3 -m unittest discover -s tests -v` and `python3 -m code.evaluation.main`.

1. Historical email ownership and two subjects claiming the same email over conflicting time windows. Resolution succeeds only when the timestamp identifies one owner; an ambiguous untimed lookup fails closed.
2. Missing subject evidence. The expected status is `INCOMPLETE`; an empty evidence set never proves erasure.
3. Expired retention period. The retained audit record becomes subject to deletion and requires deletion verification.
4. Shared support conversation with direct identifiers. The policy requires redaction rather than deleting the conversation.
5. Attributable analytics data. A compliant anonymized record is verified as anonymized.
6. Account tombstone with direct identifiers. Preserve the tombstone reference and plan redaction.
7. Active connector flow and an unsafe backup restore path. Both require a control action followed by a verification check.

All 31 unit tests pass. The evaluation runner reports seven custom scenario checks passing. The independent validator accepts the regenerated 518-row root `output.csv`.

## Failures found and improvements made

- Identity aliases previously used last-row-wins ownership. Identity resolution now maintains multi-owner claims and temporal validity windows; the request email is resolved at `requested_at` and ambiguous claims fail closed.
- A SQL profile row with a non-`ACTIVE` account status was incorrectly interpreted as an absent row. SQL row presence now remains `PRESENT`; status does not prove physical or logical absence.
- A policy-required retained record could be skipped, and retention expiry was not consistently applied in the completion path. Missing retention proof now prevents `COMPLETE`, and completion evaluates the rule at `audit_at`.
- A `BLOCKED` backup was incorrectly treated as a missing `PRESENT` retained record and caused the entire step sequence to be discarded. Backup restore control is now evaluated as its own obligation; it emits `VERIFY_RESTORE_BLOCKED`, and one unresolved resource no longer clears other determined checks. The three affected sample statuses now match.
- A trace from `legacy_contact_index` was assigned the generic support-message category and redacted. It is now categorized as `SECONDARY_IDENTIFIER`, so the supplied policy's `DELETE` action is used. A regression test verifies the parsed category and finding/remediation/verification operations. Public status and exact-sequence totals remain 29/32 and 8/32 because the remaining expected account verification has no linked record evidence.
- Tombstone rows containing only the policy-permitted stable `user_id` were parsed as `PRESENT` and then misclassified as exposing direct PII. Tombstone state is now reconciled against name, email, phone, and email-hash fields: stable-reference-only rows verify as `REDACTED`, while direct identifiers remain a finding. Four full-dataset requests (`case_543`, `case_545`, `case_547`, `case_549`) correctly changed from `INCOMPLETE` to `COMPLETE`; the public sample is unaffected. A regression test covers this case.
- Pre-request `LINK_RESOURCE_IDENTITY` catalog events were excluded from lineage discovery. They are now considered through `audit_at`, while evidence snapshots still ground the resulting state.
- Multiple readback rows inside one captured log shared the same manifest timestamp and could select stale state. Parsed observation timestamps now order those rows, while manifest capture time still bounds when evidence becomes available.
- Added `code/validate_output.py` as a separate contract checker and regression tests for identity conflict, missing evidence, retention, redaction, anonymization, tombstones, active flows, and restore risk.
- Replica observations now carry source location and observation time; later states supersede stale ones, while equal-time disagreement fails closed as `UNKNOWN`. A source-of-truth hierarchy for all replica types and exhaustive inventory completeness are still unverified.

## Full evaluation run

The regenerated root `output.csv` contains exactly one sorted row for each of the 518 requests, with statuses 161 `COMPLETE`, 347 `INCOMPLETE`, and 10 `NOT_APPLICABLE`. `python3 -m code.validate_output` passed on the generated artifact. The evidence coverage and risk graph artifacts were regenerated under `evaluation_artifacts/final_run/`. This is structural validation only; evidence interpretation and policy completeness remain subject to the limitations above.
