# Evidence Coverage Report

Generated from all 518 requests using the participant-facing identity, activity, manifest, evidence, and policy files.

## Case-level evidence-chain coverage

Ten requests are non-deletion requests and are excluded from the authorized-request denominator. Of the 508 deletion-authorized cases:

| Coverage class | Cases | Share of authorized cases | Interpretation |
| --- | ---: | ---: | --- |
| Evidence-backed closure over discovered resources | 161 | 31.69% | Output is `COMPLETE`; each emitted verification cites evidence available by `audit_at`. This does not prove that the discovered inventory is exhaustive. |
| Partial chain with cited findings | 319 | 62.80% | At least one policy violation is supported by evidence and still needs remediation or post-action verification. |
| No linked resource evidence | 25 | 4.92% | Subject was resolved, but no applicable resource was linked from available evidence. |
| Other unresolved proof gap | 0 | 0.00% | The remaining no-finding cases are accounted for by no linked resource evidence or equal-time conflicts. |
| Equal-time state conflict | 3 | 0.59% | Latest observations conflict across locations; status is treated as `UNKNOWN`, not absent or compliant. |

Across all 518 requests, 161 (31.08%) have evidence-backed closure over discovered resources, 347 (66.99%) have partial or unresolved chains, and 10 (1.93%) are not applicable. Percentages may not sum to 100 due to rounding.

## Reason-coded unresolved obligations

The regenerated `evaluation_artifacts/final_run/unresolved_obligations.json` contains **619** unresolved obligation records:

| Reason code | Obligations | Meaning |
| --- | ---: | --- |
| `POLICY_ACTION_REQUIRED` | 591 | A record, PII exposure, active flow, or restore path has evidence but requires the policy action and a later verification. |
| `SUBJECT_LINEAGE_GAP` | 25 | No resource was linked; the artifact lists systems where subject-linked inventory evidence is missing. |
| `CONFLICTING_LATEST_OBSERVATIONS` | 3 | Equally recent observations disagree; an authoritative attestation or later reconciled observation is needed. |

Each item records its case, `audit_at`, system, resource/location when known, observed state, applicable action, evidence IDs, and missing proof. The output contract has no dedicated uncertainty status, so these reason codes are provided as a separate diagnostic artifact.

The regenerated `evaluation_artifacts/final_run/resurrection_risk_graph.json` contains one reachability graph per authorized case (508 graphs) and six evidence-linked resurrection-risk paths across six cases. Paths connect active sync/restore sources to subject-linked records that are absent, redacted, or anonymized. They are potential reintroduction paths, not claims that a restore or sync has already occurred.

## Interpretation limits

“Evidence-backed closure” means every resource discovered by this pipeline had a cited compliant verification. It is not an attestation that every corporate store was inventoried. Open-world inventory completeness, hidden evaluation labels, and real-company operational control effectiveness cannot be established from the supplied files alone.
