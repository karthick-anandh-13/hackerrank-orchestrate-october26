# Usage Report

## Final full-dataset run

The final run processed 518 requests and generated the repository-root `output.csv` using deterministic Python rules and local evidence parsers. It made no external model or provider calls.

| Provider / model | Calls | Input tokens | Output tokens | Total tokens | Estimated cost |
| --- | ---: | ---: | ---: | ---: | ---: |
| None (local Python pipeline) | 0 | 0 | 0 | 0 | $0.00 |
| **Overall** | **0** | **0** | **0** | **0** | **$0.00** |

| Measure | Overall | Average per request |
| --- | ---: | ---: |
| Requests | 518 | 1 |
| Model input tokens | 0 | 0 |
| Model output tokens | 0 | 0 |
| Total model tokens | 0 | 0 |
| Estimated model cost | $0.00 | $0.00 |

The pipeline uses the Python standard library. When installed, `pdftotext` and `tesseract` are invoked locally to extract text from participant-provided PDFs and screenshots; these tools do not call a model provider. Their processing time and system resources are not token usage and are not included in model cost.

## Validation methodology

The step taxonomy is derived from the participant-facing output contract and encoded as a fixed ordering of the allowed phases and operation/state types. We checked determinism with synthetic regression tests that reverse resource discovery order, exercised the policy and temporal rules with synthetic edge cases, and used `code/validate_output.py` to independently check the generated file's structure and citations. Public outputs were used to diagnose mismatches. The contact-index correction was based on the evidence's `legacy_contact_index` provenance and the supplied `SECONDARY_IDENTIFIER` deletion rule, then covered by a synthetic regression test; no case ID or resource ID was added to prediction logic. All 32 cases were inspected, so there is no blind public-sample holdout and the sample score is diagnostic, not independent validation. Hidden-set accuracy cannot be measured locally.

For the same 518-request data run, the evidence coverage report classified 157 authorized cases as evidence-backed closure over discovered resources, 323 as partial chains with cited findings, and 28 as unresolved proof gaps (25 no-link cases and 3 equal-time conflicts). Ten requests were not applicable. This classification does not prove inventory exhaustiveness.
