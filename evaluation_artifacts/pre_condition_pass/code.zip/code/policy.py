"""Policy engine and step ordering definitions."""

import csv
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple


@dataclass
class DeletionRule:
    rule_id: str
    data_category: str
    condition: str
    required_action: str


class PolicyEngine:
    # The participant output contract exposes only these three phases. Within
    # each phase, operation order is policy/state driven and independent of
    # evidence ingestion or resource discovery order.
    CANONICAL_STEP_TAXONOMY = (
        ("FINDING", "REPORT_REMAINING_RECORD"),
        ("FINDING", "REPORT_EXPOSED_PII"),
        ("FINDING", "REPORT_ACTIVE_DATA_FLOW"),
        ("FINDING", "REPORT_RESTORE_RISK"),
        ("REMEDIATION", "DISABLE_DATA_FLOW"),
        ("REMEDIATION", "BLOCK_RESTORE"),
        ("REMEDIATION", "DELETE_RECORD"),
        ("REMEDIATION", "REDACT_RECORD"),
        ("REMEDIATION", "ANONYMIZE_RECORD"),
        ("VERIFICATION", "VERIFY_RECORD_ABSENT"),
        ("VERIFICATION", "VERIFY_RECORD_PRESENT"),
        ("VERIFICATION", "VERIFY_RECORD_REDACTED"),
        ("VERIFICATION", "VERIFY_RECORD_ANONYMIZED"),
        ("VERIFICATION", "VERIFY_DATA_FLOW_DISABLED"),
        ("VERIFICATION", "VERIFY_RESTORE_BLOCKED"),
    )

    PHASE_ORDER = {
        'FINDING': 1,
        'REMEDIATION': 2,
        'VERIFICATION': 3,
    }

    OPERATION_ORDER = {
        # FINDINGS
        'REPORT_REMAINING_RECORD': 1,
        'REPORT_EXPOSED_PII': 2,
        'REPORT_ACTIVE_DATA_FLOW': 3,
        'REPORT_RESTORE_RISK': 4,
        # REMEDIATION
        'DISABLE_DATA_FLOW': 10,
        'BLOCK_RESTORE': 11,
        'DELETE_RECORD': 12,
        'REDACT_RECORD': 13,
        'ANONYMIZE_RECORD': 14,
        # VERIFICATION
        'VERIFY_RECORD_ABSENT': 20,
        'VERIFY_RECORD_PRESENT': 21,
        'VERIFY_RECORD_REDACTED': 22,
        'VERIFY_RECORD_ANONYMIZED': 23,
        'VERIFY_DATA_FLOW_DISABLED': 24,
        'VERIFY_RESTORE_BLOCKED': 25,
    }

    def __init__(self, rules_path: str):
        self.rules: Dict[str, DeletionRule] = {}
        self._load_rules(rules_path)

    def _load_rules(self, path: str):
        with open(path, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                r = DeletionRule(
                    rule_id=row['rule_id'],
                    data_category=row['data_category'],
                    condition=row['condition'],
                    required_action=row['required_action'],
                )
                self.rules[r.data_category] = r

    @classmethod
    def step_sort_key(cls, step: dict) -> Tuple[int, int, str, str]:
        taxonomy = {operation: (phase, rank) for rank, (phase, operation)
                    in enumerate(cls.CANONICAL_STEP_TAXONOMY)}
        phase = step.get('phase', '')
        operation = step.get('operation', '')
        if operation not in taxonomy or taxonomy[operation][0] != phase:
            raise ValueError(f"Operation {operation!r} is not valid in phase {phase!r}")
        phase_rank = cls.PHASE_ORDER[phase]
        op_rank = taxonomy[operation][1]
        sys_id = step.get('system_id', '')
        res_id = step.get('resource_id', '')
        return (phase_rank, op_rank, sys_id, res_id)

    @classmethod
    def sort_steps(cls, steps: List[dict]) -> List[dict]:
        sorted_steps = sorted(steps, key=cls.step_sort_key)
        for i, s in enumerate(sorted_steps, start=1):
            s['step_no'] = i
        return sorted_steps
